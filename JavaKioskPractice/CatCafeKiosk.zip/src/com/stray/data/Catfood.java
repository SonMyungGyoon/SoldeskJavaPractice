package com.stray.data;

public class Catfood extends Product{
	
	public Catfood(String xx, int yy) {
		super(xx, yy);
	}

	@Override
	public void info() {
		super.info();
	}
}
