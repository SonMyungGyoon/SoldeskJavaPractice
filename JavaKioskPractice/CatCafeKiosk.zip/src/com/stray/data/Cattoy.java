package com.stray.data;

public class Cattoy extends Product {
	public Cattoy(String xx, int yy) {
		super(xx, yy);
	}

	@Override
	public void info() {
		super.info();
	}
}
