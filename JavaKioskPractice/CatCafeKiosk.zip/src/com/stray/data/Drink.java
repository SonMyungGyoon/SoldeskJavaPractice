package com.stray.data;

public class Drink extends Product{

	public Drink(String xx, int yy) {
		super(xx, yy);
	}

	@Override
	public void info() {
		super.info();
	}
}
